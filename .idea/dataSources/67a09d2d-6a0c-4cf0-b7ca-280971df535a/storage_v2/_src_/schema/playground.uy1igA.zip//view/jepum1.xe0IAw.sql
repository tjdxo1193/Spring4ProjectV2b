create definer = playground@`%` view 제품1 as
select `playground`.`sales_product`.`prd_no`    AS `prd_no`,
       `playground`.`sales_product`.`prd_inven` AS `prd_inven`,
       `playground`.`sales_product`.`prd_mnft`  AS `prd_mnft`
from `playground`.`sales_product`;

