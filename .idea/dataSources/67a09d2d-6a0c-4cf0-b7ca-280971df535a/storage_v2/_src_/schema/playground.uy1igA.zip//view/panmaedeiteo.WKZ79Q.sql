create definer = playground@`%` view 판매데이터 as
select `o`.`cus_id`     AS `cus_id`,
       `o`.`prd_no`     AS `prd_no`,
       `o`.`ord_no`     AS `ord_no`,
       `o`.`amount`     AS `amount`,
       `o`.`ord_adress` AS `ord_adress`,
       `o`.`ord_date`   AS `ord_date`,
       `p`.`prd_name`   AS `prd_name`,
       `p`.`prd_inven`  AS `prd_inven`,
       `p`.`prd_price`  AS `prd_price`,
       `p`.`prd_mnft`   AS `prd_mnft`,
       `c`.`cus_name`   AS `cus_name`,
       `c`.`cus_age`    AS `cus_age`,
       `c`.`cus_tier`   AS `cus_tier`,
       `c`.`cus_job`    AS `cus_job`,
       `c`.`cus_point`  AS `cus_point`
from ((`playground`.`sales_order` `o` join `playground`.`sales_product` `p` on (`o`.`prd_no` = `p`.`prd_no`))
         join `playground`.`sales_customers` `c` on (`o`.`cus_id` = `c`.`cus_id`));

