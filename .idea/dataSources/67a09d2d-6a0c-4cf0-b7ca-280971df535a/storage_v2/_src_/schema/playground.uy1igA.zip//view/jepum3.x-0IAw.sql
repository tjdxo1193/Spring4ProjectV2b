create definer = playground@`%` view 제품3 as
select `playground`.`sales_product`.`prd_name`  AS `prd_name`,
       `playground`.`sales_product`.`prd_inven` AS `prd_inven`,
       `playground`.`sales_product`.`prd_mnft`  AS `prd_mnft`
from `playground`.`sales_product`;

